<div>
    <!-- Header Content Section -->
    <?php $__env->startSection('header-content'); ?>
        Header Page
    <?php $__env->stopSection(); ?>

    <div class="card">
        <div class="card-body">
            <div class="container">

                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <?php if(session('status')): ?>
                            <div class="alert alert-info">
                                <?php echo e(session('status')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12 col-md-12 col-lg-12">
                        <?php echo e($header_content); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\base-app-laravel-livewire\resources\views/livewire/index.blade.php ENDPATH**/ ?>