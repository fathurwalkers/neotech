<div>
    <div class="card fat">
        <div class="card-body">
            <h4 class="card-title">Login</h4>
            <div class="row">
                <div class="col-sm-12 col-md-12 col-lg-12">
                    <?php if(session('status')): ?>
                        <div class="alert alert-info">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <form wire:submit.prevent="login">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="username">Username</label>
                    <input wire:model="username" id="username" type="text" class="form-control" autofocus>
                    <?php if(session('status_fail_username')): ?>
                        <div class="invalid-feedback">
                            <?php echo e(session('status_fail_username')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <label for="password">Password
                        <a href="forgot.html" class="float-right">
                            Forgot Password?
                        </a>
                    </label>
                    <input wire:model="password" id="password" type="password" class="form-control">
                    <?php if(session('status_fail_password')): ?>
                        <div class="invalid-feedback">
                            <?php echo e(session('status_fail_password')); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <div class="form-group">
                    <div class="custom-checkbox custom-control">
                        <input type="checkbox" id="remember" class="custom-control-input">
                        <label for="remember" class="custom-control-label">Remember Me</label>
                    </div>
                </div>

                <div class="form-group m-0">
                    <button class="btn btn-primary btn-block">
                        Login
                    </button>
                </div>
                <div class="mt-4 text-center">
                    Don't have an account? <a href="<?php echo e(route('dashboard')); ?>">Create One</a>
                </div>
            </form>

        </div>
    </div>
</div>
<?php /**PATH C:\Users\fathurwalkers\Desktop\htdocs\base-app-laravel-livewire\resources\views/livewire/auth-login.blade.php ENDPATH**/ ?>