<?php return array (
  'auth-login' => 'App\\Http\\Livewire\\AuthLogin',
  'components.navbar' => 'App\\Http\\Livewire\\Components\\Navbar',
  'components.sidebar' => 'App\\Http\\Livewire\\Components\\Sidebar',
  'homepage.index' => 'App\\Http\\Livewire\\Homepage\\Index',
  'index' => 'App\\Http\\Livewire\\Index',
);